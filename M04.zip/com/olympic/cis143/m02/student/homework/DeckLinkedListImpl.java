package com.olympic.cis143.m02.student.homework;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

import com.olympic.cis143.m02.student.homework.Card.Suit;
import com.olympic.cis143.m02.student.homework.Card.Value;

/**
 * Note that you can think of the deck implementation as being an iterator in that its creates and used once. Meaning, when a card is
 * delt is  MUST be removed from the deck.
 */
public class DeckLinkedListImpl {

    /**
     * This will be the stack object for you to work with.
     */
    private Deque<Card> deck = new ArrayDeque<>();

    /**
     * Const.
     * @param jokers True if you want jokers in this deck.
     */
    public DeckLinkedListImpl(final boolean jokers) {
        this.createDeck(jokers);
    }

    /**
     * Private. THis is the place where you will need to create a deck of cards. You can iterate throug
     * ther enums in Card.
     *
     * Some rules:
     * ============
     * 1. Note the boolean jokers parameter. If true add the Jokers to the deck with a Card.Suite.NONE.
     * 2. Do not create cards, other than jokers, with a Card.Suite.NONE.
     *
     * Outcome
     * ========
     * if jokers == true, 54 cards will be created.
     * if jokers == false, 52 cards are created.
     *
     * @param jokers True if you want jokers added to the deck.
     */
    private void createDeck(final boolean jokers) {
    	for(Card.Suit s : Card.Suit.values())
    	{
    		if(s == Card.Suit.NONE)
    		{
    			continue;
    		}
    		for(Card.Value v : Card.Value.values())
    		{
    			if(v == Card.Value.JOKER)
    			{
    				continue;
    			}
    			deck.offer(new Card(s, v));
    		}
    	}
    	if(jokers)
    	{
    		deck.offer(new Card(Suit.NONE, Card.Value.JOKER));
    		deck.offer(new Card(Suit.NONE, Card.Value.JOKER));
    	}
    }
    /**
     * Gets the deck.
     * @return The deck.
     */
    public Deque<Card> getDeck() {
        return this.deck;
    }
    /**
     * Randomize and shuffle the deck of cards.
     */
    public void shuffle() {
    	//Collections.shuffle((Deque<?>) deck);
    	//We need to convert the Deque of cards to an Object Array
    	Object[] temp = deck.toArray();
    	int length = temp.length;
    	//Go through the array 5 times
    	for(int cycle = 0;cycle<5;cycle++)
    	{
    		//Give every card a chance to swap
    		for(int first=0;first < length;first++)
    		{
    			swap(temp, first, (int)Math.floor(Math.random() * length));
    		}
    	}
    	deck.clear();
    	//put the object back into the cleared deck
    	for(Object element : temp)
    	{
    		deck.offer((Card)element);
    	}
    }
    
    //exchange two elements
    private void swap(Object[] temp, int first, int second) {
		Object hold = temp[first];
		temp[first] = temp[second];
		temp[second] = hold;
	}

	/**
     * True if the deck has cards remaining else false.
     * @return
     */
    public boolean hasNext() {
        return deck.size() > 0;
    }

    /**
     * Always call the hasNext() method before calling this method.
     * This method should get the next card in the deck.
     *
     * Outcome
     * =======
     * The method will remove the next from the deck and return it in the method.
     *
     * If the deck is empty it should through a RuntimeException.
     * @return
     */
    public Card dealCard() {
    	Card card = deck.poll();
        if(card != null)
        {
        	return(card);
        }
		throw new RuntimeException("The deck is empty");
    }
}
