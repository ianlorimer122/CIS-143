// Ian Lorimer
package com.olympic.cis143.m03.student.homework;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.olympic.cis143.m03.student.homework.Card.Suit;

public class DeckIteratorImpl implements Deck {
	private LinkedList<Card> deck = new LinkedList<Card>();

	public DeckIteratorImpl(boolean jokers) {
		this.createDeck(jokers);
	}

	@Override
	public List<Card> getDeck() {
		return this.deck;
	}

	@Override
	public void shuffle() {
		// TODO Auto-generated method stub
		Collections.shuffle((List<?>) deck);
	}

	@Override
	public boolean hasNext() {
		return deck.size() > 0;
	}

	@Override
	public Card dealCard() {
		Card card = deck.poll();
		if(card != null)
		{
			return card;
		}
		throw new RuntimeException("There are no cards left");
	}
	private void createDeck(final boolean jokers) {
    	for(Card.Suit s : Card.Suit.values())
    	{
    		if(s == Card.Suit.NONE)
    		{
    			continue;
    		}
    		for(Card.Value v : Card.Value.values())
    		{
    			if(v == Card.Value.JOKER)
    			{
    				continue;
    			}
    			deck.offer(new Card(s, v));
    		}
    	}
    	if(jokers)
    	{
    		deck.offer(new Card(Suit.NONE, Card.Value.JOKER));
    		deck.offer(new Card(Suit.NONE, Card.Value.JOKER));
    	}
    }

}
