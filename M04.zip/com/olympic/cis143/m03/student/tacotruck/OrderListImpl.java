package com.olympic.cis143.m03.student.tacotruck;

import java.util.ArrayList;

public class OrderListImpl implements Orders {
	private ArrayList<Object> order = new ArrayList<>();
	@Override
	public void addOrder(TacoImpl tacoOrder) {
		// TODO Auto-generated method stub
		this.order.add(tacoOrder);
	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return !this.order.isEmpty();
	}

	@Override
	public TacoImpl closeNextOrder() {
		if(this.howManyOrders() > 0)
		{
			return (TacoImpl) this.order.remove(0);
		}
		throw new RuntimeException("Order list is empty");
	}

	@Override
	public int howManyOrders() {
		// TODO Auto-generated method stub
		return this.order.size();
	}

}
